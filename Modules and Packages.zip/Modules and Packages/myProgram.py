#from module import fun_in_module

#fun_in_module()


from MyMainPackage import ScriptInMainPackage
from MyMainPackage.MySubPackage import ScriptInSubPackage

ScriptInMainPackage.main_report()
ScriptInSubPackage.sub_report()