def fun_in_module():
	print("Function inside module")