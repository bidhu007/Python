from module import fun_in_module

fun_in_module()
